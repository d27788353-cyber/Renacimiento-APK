package com.renacimiento

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val devocional = """
> En el principio era el Verbo,
> y el Verbo era con Dios,
> y el Verbo era Dios.
> — Juan 1:1
""".trimIndent()

    private lateinit var terminalText: TextView
    private var index = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        terminalText = findViewById(R.id.terminalText)
        escribirTerminal()
    }

    private fun escribirTerminal() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (index < devocional.length) {
                    terminalText.append(devocional[index].toString())
                    index++
                    handler.postDelayed(this, 35)
                }
            }
        }, 500)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        // Más adelante aquí revelaremos el contenido principal
        return super.onTouchEvent(event)
    }
}
